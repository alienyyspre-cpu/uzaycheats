@echo off
title Uzay Cheat's - Riot Hesap Oluşturucu
color 0A
echo ========================================
echo      UZAY CHEAT'S - RIOT GENERATOR
echo ========================================
echo.

:: Python kontrolu
python --version >nul 2>&1
if errorlevel 1 (
    echo [HATA] Python bulunamadi!
    echo Lutfen Python'u https://www.python.org/downloads/ adresinden indirin.
    echo Kurulum sirasinda "Add Python to PATH" secenegini isaretleyin.
    pause
    exit /b 1
)

echo [BILGI] Python bulundu!
echo.

:: Gerekli kutuphaneleri kontrol et ve yukle
echo Gerekli kutuphaneler kontrol ediliyor...
echo.

echo DrissionPage kontrol ediliyor...
python -c "import DrissionPage" >nul 2>&1
if errorlevel 1 (
    echo DrissionPage yukleniyor...
    pip install DrissionPage
    echo.
) else (
    echo DrissionPage zaten yuklu.
    echo.
)

echo Rich kontrol ediliyor...
python -c "import rich" >nul 2>&1
if errorlevel 1 (
    echo Rich yukleniyor...
    pip install rich
    echo.
) else (
    echo Rich zaten yuklu.
    echo.
)

echo Winsound kontrol ediliyor...
python -c "import winsound" >nul 2>&1
if errorlevel 1 (
    echo Winsound yukleniyor...
    pip install winsound
    echo.
) else (
    echo Winsound zaten yuklu.
    echo.
)

echo ========================================
echo Program baslatiliyor...
echo ========================================
echo.

:: Script'i calistir
python riot_generator.py

echo.
echo ========================================
echo Program sonlandi.
echo Hesaplar created.txt dosyasina kaydedildi.
echo ========================================
pause