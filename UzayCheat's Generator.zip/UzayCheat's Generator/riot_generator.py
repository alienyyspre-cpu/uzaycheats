import os
import time
import random
import string
import winsound
from DrissionPage import ChromiumPage, ChromiumOptions
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt

console = Console()

LOGO = r"""
[bold red]
 ██╗   ██╗███████╗ █████╗ ██╗   ██╗
██║   ██║╚══███╔╝██╔══██╗╚██╗ ██╔╝
██║   ██║  ███╔╝ ███████║ ╚████╔╝ 
██║   ██║ ███╔╝  ██╔══██║  ╚██╔╝  
██║   ██║███████╗██║  ██║   ██║   
╚██████╔╝╚══════╝╚═╝  ╚═╝   ╚═╝   
[/bold red]
[bold cyan]
 ██████╗██╗  ██╗███████╗ █████╗ ████████╗
██╔════╝██║  ██║██╔════╝██╔══██╗╚══██╔══╝
██║     ███████║█████╗  ███████║   ██║   
██║     ██╔══██║██╔══╝  ██╔══██║   ██║   
╚██████╗██║  ██║███████╗██║  ██║   ██║   
 ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ██║   ██║   
[/bold cyan]
[dim]              Riot Hesap Generator[/dim]
"""

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def beep():
    for _ in range(3):
        winsound.Beep(1000, 300)

def gen_email():
    domains = ["gmail.com", "outlook.com", "hotmail.com"]
    user = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
    return f"{user}@{random.choice(domains)}"

def gen_username():
    return f"generated{str(int(time.time()))[-4:]}"

def save(user, pwd):
    with open("created.txt", "a", encoding="utf-8") as f:
        f.write(f"{user}:{pwd}\n")

def show_info(email, user, pwd):
    t = Table(show_header=False, border_style="cyan", padding=(0, 2))
    t.add_column("Key", style="bold yellow")
    t.add_column("Value", style="green")
    t.add_row("Email", email)
    t.add_row("Username", user)
    t.add_row("Password", pwd)
    console.print(t)

def create(page):
    page.get("https://www.riotgames.com/tr")
    page.ele('css:[data-testid="riotbar:account:button-login"]', timeout=30).click()
    page.ele('css:a[href*="signup"]', timeout=30).click()

    email = gen_email()
    page.ele('css:[data-testid="riot-signup-email"]', timeout=30).input(email)
    page.ele('css:[data-testid="btn-signup-submit"]', timeout=10).click()

    page.ele('css:[data-testid="riot-signup-birthdate-day"]', timeout=30).input(str(random.randint(1, 30)))
    page.ele('css:[data-testid="riot-signup-birthdate-month"]').input(str(random.randint(1, 12)))
    page.ele('css:[data-testid="riot-signup-birthdate-year"]').input(str(random.randint(1990, 2010)))
    page.ele('css:[data-testid="btn-signup-submit"]', timeout=10).click()

    username = gen_username()
    u = page.ele('css:[data-testid="riot-signup-username"]', timeout=30)
    u.clear()
    u.input(username)
    page.ele('css:[data-testid="btn-signup-submit"]', timeout=10).click()

    password = username + "A1!"
    page.ele('css:[data-testid="input-password"]', timeout=30).input(password)
    c = page.ele('css:[data-testid="password-confirm"]')
    c.input(password)

    while 'step=password' in page.url:
        page.run_js('''
            var el = arguments[0];
            var nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
            nativeSetter.call(el, '');
            el.dispatchEvent(new Event('input', { bubbles: true }));
            nativeSetter.call(el, arguments[1]);
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
        ''', c, password)
        page.ele('css:[data-testid="btn-signup-submit"]').click()

    cb = page.ele('css:#tos-checkbox', timeout=30)
    page.run_js("arguments[0].removeAttribute('disabled')", cb)
    cb.click()
    page.ele('css:[data-testid="btn-accept-tos"]', timeout=10).click()

    url = page.url
    for _ in range(10):
        if page.url != url:
            break
        if page.ele('css:[data-testid="error-message"]', timeout=0):
            console.print(Panel("[bold red]✗ Kullanıcı adı veya şifre hatalı.[/bold red]", border_style="red"))
            return False
        time.sleep(1)

    if page.url != url:
        console.print(Panel("[bold green]✓ Hesap oluşturuldu![/bold green]", border_style="green"))
        show_info(email, username, password)
        save(username, password)
        return True
    
    beep()
    console.print(Panel("[bold yellow]⚠ CAPTCHA! Manuel çöz.[/bold yellow]", border_style="yellow"))
    Prompt.ask("[yellow]Çözdükten sonra Enter'a bas[/yellow]")
    if page.url != url:
        console.print(Panel("[bold green]✓ Hesap oluşturuldu![/bold green]", border_style="green"))
        show_info(email, username, password)
        save(username, password)
        return True
    console.print(Panel("[bold red]✗ Başarısız.[/bold red]", border_style="red"))
    return False

def main():
    clear()
    console.print(LOGO)
    console.print(Panel(
        "[bold yellow]Uzay Cheat's[/bold yellow]\n"
        "[bold cyan]┌──────────────────────────────────┐[/bold cyan]\n"
        "[bold cyan]│  [bold purple]Discord:[/bold purple] [bold blue]https://discord.gg/pwhprZEqh[/bold blue]  │[/bold cyan]\n"
        "[bold cyan]└──────────────────────────────────┘[/bold cyan]", 
        border_style="magenta"
    ))

    count = int(Prompt.ask("[bold cyan]Kaç hesap[/bold cyan] [dim](0=sınırsız)[/dim]"))
    ok = 0
    fail = 0
    i = 0

    while count == 0 or i < count:
        i += 1
        label = f"Hesap {i}" if count == 0 else f"Hesap {i}/{count}"
        console.print(f"\n[bold yellow]━━━ {label} ━━━[/bold yellow]")

        opts = ChromiumOptions()
        opts.set_argument('--start-maximized')
        opts.set_argument('--disable-blink-features=AutomationControlled')
        page = ChromiumPage(opts)

        try:
            if create(page):
                ok += 1
            else:
                fail += 1
        except Exception as e:
            console.print(Panel(f"[bold red]✗ {e}[/bold red]", border_style="red"))
            fail += 1
        finally:
            try:
                page.quit()
            except:
                pass

    console.print(Panel(
        f"[green]Başarılı: {ok}[/green]\n[red]Başarısız: {fail}[/red]\n[cyan]Toplam: {ok+fail}[/cyan]\n[cyan]→ created.txt[/cyan]",
        title="SONUÇ", border_style="magenta"
    ))

if __name__ == "__main__":
    main()